# rustup

This plugin adds completion for [`rustup`](https://rustup.rs/), the toolchain installer for the Rust programming language.

To use it, add `rustup` to the plugins array in your zshrc file:

```zsh
plugins=(... rustup)
```
